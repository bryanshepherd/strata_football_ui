import React, { createContext, useContext, useReducer, useEffect } from 'react';
import DownDistanceCalculator, { 
  calculateNextDownDistance, 
  applyPenaltyToDownDistance, 
  shouldEndDrive, 
  promptForGameTime 
} from '../utils/DownDistanceCalculator';

const FootballGameContext = createContext();

const initialState = {
  gameData: null,
  isSubmitting: false,
  error: null,
  debugMode: false,
  debugGameId: '',
  apiStatus: 'connecting' // 'connected', 'connecting', 'error', 'disconnected'
};

function reducer(state, action) {
  switch (action.type) {
    case 'FETCH_START':
      return { ...state, isSubmitting: true, error: null };
    case 'FETCH_SUCCESS':
      return { 
        ...state, 
        gameData: action.payload, 
        isSubmitting: false, 
        error: null,
        apiStatus: 'connected'
      };
    case 'FETCH_ERROR':
      return { 
        ...state, 
        error: action.payload, 
        isSubmitting: false,
        apiStatus: 'error'
      };
    case 'SUBMIT_START':
      return { ...state, isSubmitting: true, error: null };
    case 'SUBMIT_SUCCESS':
      return { 
        ...state, 
        gameData: action.payload, 
        isSubmitting: false, 
        error: null,
        apiStatus: 'connected'
      };
    case 'SUBMIT_ERROR':
      return { 
        ...state, 
        error: action.payload, 
        isSubmitting: false,
        apiStatus: 'error'
      };
    case 'SET_GAME_DATA':
      return { 
        ...state, 
        gameData: action.payload, 
        error: null,
        apiStatus: 'connected'
      };
    case 'SET_API_STATUS':
      return { ...state, apiStatus: action.payload };
    case 'CLEAR_ERROR':
      return { ...state, error: null };
    case 'SET_DEBUG_GAME_ID':
      return { ...state, debugGameId: action.payload };
    case 'TOGGLE_DEBUG_MODE':
      return { ...state, debugMode: !state.debugMode };
    // Additional supported action types
    case 'SET_SUBMITTING':
      return { ...state, isSubmitting: action.payload };
    case 'SET_ERROR':
      return { ...state, error: action.payload, isSubmitting: false, apiStatus: 'error' };
    case 'SET_CONNECTED':
      return { ...state, apiStatus: action.payload ? 'connected' : 'disconnected' };
    case 'SET_LAST_PLAY':
      return { ...state, lastPlayData: action.payload };
    case 'UPDATE_DRIVE_STATS':
      return { ...state, currentDrive: action.payload };
    case 'SET_CURRENT_DRIVE':
      return { ...state, currentDrive: action.payload };
    default:
      return state;
  }
}

export function FootballGameProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  // Use proxy path for API calls (configured in vite.config.js)
  const API_BASE = '/strata_football/api';

  const fetchGameState = async (gameId) => {
    try {
      const response = await fetch(`${API_BASE}/get_game_state.php?gameId=${gameId}`);
      if (!response.ok) { const _txt = await response.text().catch(()=> ''); console.error('fetch_game_state failed', {status: response.status, body: _txt}); throw new Error(`Failed to fetch game state: ${response.status}`);}
      
      const apiData = await response.json();
      
      // Transform API data to match component expectations
      const transformedData = {
        game_info: {
          game_id: apiData.gameInfo?.game_id || gameId,
          home_team_name: apiData.gameInfo?.home_team_name || 'Home Team',
          home_team_short: apiData.gameInfo?.home_team_short || 'HOME',
          home_team_abbr: apiData.gameInfo?.home_team_abbr || 'HOME',
          visitor_team_name: apiData.gameInfo?.visitor_team_name || 'Away Team',
          visitor_team_short: apiData.gameInfo?.visitor_team_short || 'AWAY',
          visitor_team_abbr: apiData.gameInfo?.visitor_team_abbr || 'AWAY',
          home_team_id: apiData.gameInfo?.home_team_id || 1,
          visitor_team_id: apiData.gameInfo?.visitor_team_id || 2,
          game_date: apiData.gameInfo?.game_date || new Date().toISOString(),
          venue: apiData.gameInfo?.venue || 'Stadium'
        },
        live_state: {
          game_status: apiData.gameState?.game_status || 'in_progress',
          quarter: apiData.gameState?.quarter || 1,
          time_remaining: apiData.gameState?.time_remaining || 900,
          possession: (apiData.gameState?.possession || 'home').toLowerCase(), // 'home' | 'visitor'
          down: apiData.gameState?.down || 1,
          distance: apiData.gameState?.distance || 10,
          yard_line: apiData.gameState?.yard_line || 'H25',
          home_score: apiData.gameState?.home_score || 0,
          visitor_score: apiData.gameState?.visitor_score || 0,
          home_timeouts: apiData.gameState?.home_timeouts || 3,
          visitor_timeouts: apiData.gameState?.visitor_timeouts || 3,
          play_clock: apiData.gameState?.play_clock || 40
        },
        recent_plays: apiData.recent_plays || [],
        team_stats: apiData.team_stats || { home: {}, visitor: {} },
        player_stats: apiData.player_stats || { home: [], visitor: [] },
        stats: apiData.stats || { teams: { home: {}, visitor: {} } },
        rosters: apiData.rosters || { home: [], visitor: [] }
      };
      
      console.log('API Response:', apiData);
      console.log('Transformed Data:', transformedData);
      console.log('Transformed live_state:', transformedData.live_state);
      
      dispatch({ type: 'SET_GAME_DATA', payload: transformedData });
      dispatch({ type: 'SET_CONNECTED', payload: true });
      
      return transformedData;
    } catch (error) {
      console.error('Error fetching game state:', error);
      dispatch({ type: 'SET_ERROR', payload: error.message });
      dispatch({ type: 'SET_CONNECTED', payload: false });
      throw error;
    }
  };

  const submitEvent = async (eventData) => {
    // [CTX IN] Enhanced entry logging with comprehensive state
    console.log('[CTX IN] submitEvent entry - comprehensive state:', {
      play_type: eventData.play_type,
      sub_type: eventData.sub_type,
      is_kickoff: eventData.is_kickoff,
      end_yard_line: eventData.end_yard_line,
      finalYardLine: eventData.finalYardLine,
      post_yard_line: eventData.post_yard_line,
      eventDataKeys: Object.keys(eventData),
      timestamp: new Date().toISOString()
    });

    // 3a) Log entry with kickoff detection (keep for backward compatibility)
    console.log('[KICK API] submitEvent entry:', {
      play_type: eventData.play_type,
      sub_type: eventData.sub_type,
      is_kickoff: eventData.is_kickoff,
      end_yard_line: eventData.end_yard_line,
      finalYardLine: eventData.finalYardLine,
      eventDataKeys: Object.keys(eventData)
    });

    dispatch({ type: 'SET_SUBMITTING', payload: true });
    dispatch({ type: 'CLEAR_ERROR' });

    try {
      // Get current game state for down-distance calculation
      const currentGameState = state.gameData?.live_state || {};
      
      // Calculate next down-distance if this is a play (not game control)
      let enhancedEventData = { ...eventData };
      // Hoist calculation outputs so we can safely reference them later
      let postPlayState = null;
      let resolvedFinalSpot = null;

      // Normalize empty string IDs to null
      const idFields = [
        'primary_player_id','secondary_player_id','tackler1','tackler2',
        'defender','returner','kicker','quarterback','receiver','forcedBy',
        'recoveringPlayer','onsideRecoveringPlayer','fairCatchPlayer','muffedPlayer'
      ];
      idFields.forEach((k) => {
        if (enhancedEventData[k] === '') enhancedEventData[k] = null;
      });
      
      // DEBUG: Track end_yard_line field through enhancement process
      console.log('🔍 [FIELD TRACKING] Original eventData end_yard_line:', eventData.end_yard_line);
      console.log('🔍 [FIELD TRACKING] Initial enhancedEventData end_yard_line:', enhancedEventData.end_yard_line);
      
      if (eventData.play_type && eventData.play_type !== 'GAME_CONTROL') {
        // Map possession to letter form for calculator
        const possessionLetter = (currentGameState.possession || 'home') === 'home' ? 'H' : 'V';

        // Prepare game state in the format expected by DownDistanceCalculator
        const gameStateForCalculation = {
          YardLinePosition: currentGameState.yard_line || 'H25',
          CurrentDown: currentGameState.down || 1,
          YardsToGo: currentGameState.distance || 10,
          LineToGain: currentGameState.line_to_gain || null,
          Possession: possessionLetter
        };

        // Prepare play data for calculation
        const playDataForCalculation = {
          finalYardLine: eventData.finalYardLine || eventData.endYardLine || eventData.end_yard_line,
          isFirstDown: eventData.isFirstDown || false,
          isTouchdown: eventData.isTouchdown || false,
          isTurnover: eventData.isTurnover || false,
          isSafety: eventData.isSafety || false,
          playType: eventData.play_type?.toLowerCase(),
          hasAcceptedPenalty: eventData.hasAcceptedPenalty || false,
          penaltyData: eventData.penaltyData || null,
          // CRITICAL: Pass kickoff flag to prevent DriveResult assignment
          is_kickoff: eventData.is_kickoff || false,
          play_type: eventData.play_type,
          sub_type: eventData.sub_type
        };

        console.log('🔍 [FINAL YARD LINE] Looking for:', {
          finalYardLine: eventData.finalYardLine,
          endYardLine: eventData.endYardLine, 
          end_yard_line: eventData.end_yard_line,
          resolved: eventData.finalYardLine || eventData.endYardLine || eventData.end_yard_line
        });
        
        console.log('🔍 [KICKOFF CHECK] Is this a kickoff?', {
          is_kickoff: eventData.is_kickoff,
          play_type: eventData.play_type,
          sub_type: eventData.sub_type,
          shouldSkipDriveResult: eventData.is_kickoff || (eventData.play_type === 'kick' && eventData.sub_type === 'kickoff')
        });

  // Calculate post-play state using new algorithm
        postPlayState = DownDistanceCalculator.calculatePostPlayState(
          playDataForCalculation, 
          gameStateForCalculation
        );

        console.log('[CTX CALC] postPlayState =', postPlayState);

        // 3b) Log after postPlayState calculation
        console.log('[KICK API] After postPlayState calculation:', {
          is_kickoff: eventData.is_kickoff,
          postPlayState: postPlayState,
          postYardLine: postPlayState?.postYardLine,
          resolvedFinalSpot: postPlayState?.postYardLine || playDataForCalculation?.finalYardLine
        });

        // Calculate net yards using possession-relative algorithm
        const netYards = DownDistanceCalculator.calculateNetYards(
          gameStateForCalculation.YardLinePosition,
          postPlayState.postYardLine,
          gameStateForCalculation.Possession
        );
        
        // Add calculated values to event data
        enhancedEventData = {
          ...enhancedEventData,
          // Current game state for starting position
          yard_line: currentGameState.yard_line || 'V28',  // Starting yard line position
          
          // Post-play state for database storage
          post_down: postPlayState?.postDown ?? null,
          post_distance: postPlayState?.postDistance ?? null,
          post_yard_line: postPlayState?.postYardLine ?? null,
          line_to_gain: postPlayState.lineToGain,
          
          // Calculated yards using possession-relative algorithm
          yards: netYards,
          net_yards: netYards,
          
          // Drive management
          drive_ends: postPlayState.driveEnds || false,
          drive_result: postPlayState.driveResult || null,
          
          // Game situation flags
          is_goal_to_go: postPlayState.isGoalToGo || false,
          is_red_zone: postPlayState.isRedZone || false
        };

        console.log('[CTX ENRICH] post_down/post_distance/post_yard_line =',
          enhancedEventData.post_down, enhancedEventData.post_distance, enhancedEventData.post_yard_line);

        // Resolve final spot fallback chain (ensure we have an end_yard_line) - uses hoisted variables
        resolvedFinalSpot =
          postPlayState?.postYardLine ||
          playDataForCalculation?.finalYardLine ||
          eventData.endYardLine ||
          eventData.end_yard_line ||
          null;

        // Ensure enhancedEventData carries the end_yard_line we intend to send
        if (!enhancedEventData.end_yard_line || enhancedEventData.end_yard_line === '') {
          enhancedEventData.end_yard_line = resolvedFinalSpot;
        }

        // DEBUG: Track end_yard_line field after enhancement
        console.log('🔍 [FIELD TRACKING] After enhancement end_yard_line:', enhancedEventData.end_yard_line);

        // If drive ends, prompt for game time (required by user specification)
        if (postPlayState.driveEnds) {
          const gameTime = await promptForGameTime(`${postPlayState.driveResult} - drive end`);
          enhancedEventData.game_time = gameTime;
        }

        console.log('Down-Distance Calculation (Possession-Relative + LineToGain):', {
          current: gameStateForCalculation,
          play: playDataForCalculation,
          calculated: postPlayState,
          netYards: netYards
        });
      }

      // Add timestamp, session info, and possession data; ensure snake_case keys
      const enrichedEvent = {
        ...enhancedEventData,
        post_yard_line: enhancedEventData.post_yard_line || (postPlayState ? postPlayState.postYardLine : null),
        is_kickoff: !!(
          eventData.is_kickoff ||
          (eventData.play_type === 'kick' && eventData.sub_type === 'kickoff')
        ),
        possession: currentGameState.possession || 'home',
        timestamp: new Date().toISOString(),
        session_id: 'current-session',
        user_id: 'current-user'
      };

      // Only set end_yard_line if missing to avoid overwriting
      if (!enrichedEvent.end_yard_line) {
        enrichedEvent.end_yard_line = resolvedFinalSpot || null;
      }

      // DEBUG: Track end_yard_line field in final enrichedEvent
      console.log('🔍 [FIELD TRACKING] Final enrichedEvent end_yard_line:', enrichedEvent.end_yard_line);

      // 3d) Hard guard: If kickoff without end_yard_line, reject
      if (enrichedEvent.is_kickoff && !enrichedEvent.end_yard_line) {
        console.error('[KICK API] BLOCKING SUBMIT: Kickoff missing end_yard_line');
        throw new Error('Kickoff plays require end_yard_line (tackle spot)');
      }

      // Temporary hard guard: Additional protection for kickoffs 
      if (enrichedEvent?.play_type === 'kick' && enrichedEvent?.sub_type === 'kickoff') {
        if (!enrichedEvent.end_yard_line) {
          console.error('❌ [CTX GUARD TEMP] Temporary kickoff guard triggered - missing end_yard_line');
          console.error('❌ [CTX GUARD TEMP] enrichedEvent state:', {
            end_yard_line: enrichedEvent.end_yard_line,
            post_yard_line: enrichedEvent.post_yard_line,
            finalYardLine: enrichedEvent.finalYardLine,
            keys: Object.keys(enrichedEvent)
          });
          alert('Temporary guard: end_yard_line missing. Please re-enter the Tackled at yard line.');
          dispatch({ type: 'SET_SUBMITTING', payload: false });
          return;
        }
      }

      // 3c) Log before fetch request
      console.log('[KICK API] Before fetch request:', {
        is_kickoff: enrichedEvent.is_kickoff,
        end_yard_line: enrichedEvent.end_yard_line,
        post_yard_line: enrichedEvent.post_yard_line,
        enrichedEventKeys: Object.keys(enrichedEvent)
      });

      // [CTX OUT] Enhanced comprehensive logging before API call
      console.log('[CTX OUT] Final enrichedEvent before API - comprehensive state:', {
        play_type: enrichedEvent.play_type,
        sub_type: enrichedEvent.sub_type,
        is_kickoff: enrichedEvent.is_kickoff,
        end_yard_line: enrichedEvent.end_yard_line,
        post_yard_line: enrichedEvent.post_yard_line,
        finalYardLine: enrichedEvent.finalYardLine,
        enrichedEventKeys: Object.keys(enrichedEvent),
        timestamp: new Date().toISOString()
      });

      console.log('🔎 [CTX OUT] enrichedEvent.end_yard_line =', enrichedEvent?.end_yard_line);
      console.log('🔎 [CTX OUT] enrichedEvent.post_yard_line =', enrichedEvent?.post_yard_line);

      if (enrichedEvent?.play_type === 'kick' && enrichedEvent?.sub_type === 'kickoff') {
        if (!enrichedEvent.end_yard_line) {
          console.error('❌ [CTX GUARD] kickoff without end_yard_line — aborting submit');
          alert('Internal guard: end_yard_line missing. Please re-enter the Tackled at yard line.');
          dispatch({ type: 'SET_SUBMITTING', payload: false });
          return;
        }
      }

      const response = await fetch(`${API_BASE}/submit_play_enhanced.php`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          game_id: state.gameData?.game_info?.game_id || 1000,
          play_data: enrichedEvent
        })
      });

      if (!response.ok) { const _text = await response.text().catch(()=> ''); console.error('submitEvent failed', { status: response.status, body: _text }); throw new Error(`Failed to submit event: ${response.status}`); }
      console.log('🔥 API Call Details:');
      console.log('- URL:', `${API_BASE}/submit_play_enhanced.php`);
      console.log('- game_id:', state.gameData?.game_info?.game_id || 1000);
      console.log('- play_data:', enrichedEvent);
      console.log('- full payload:', {
        game_id: state.gameData?.game_info?.game_id || 1000,
        play_data: enrichedEvent
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to submit event');
      }

      const result = await response.json();
      
      // Always refetch game state after submit
      try {
        await fetchGameState(state.gameData?.game_info?.game_id || getCurrentGameId());
      } catch (e) {
        console.warn('Refetch after submit failed:', e);
      }

      // Track the last play for drive status bar
      if (eventData.play_type && eventData.play_type !== 'GAME_CONTROL') {
        dispatch({ type: 'SET_LAST_PLAY', payload: enhancedEventData });
        
        // Update drive stats
        updateDriveStats(enhancedEventData);
      }

      dispatch({ type: 'SET_SUBMITTING', payload: false });
      return result;

    } catch (error) {
      console.error('Error submitting event:', error);
      dispatch({ type: 'SET_ERROR', payload: error.message });
      throw error;
    }
  };

  const updateDriveStats = (playData) => {
    try {
      const current = state.gameData?.live_state;
      if (!current) return;

      const possessionLetter = (current.possession || 'home') === 'home' ? 'H' : 'V';
      const startPos = current.yard_line || 'H25';
      const endPos = playData.end_yard_line || playData.finalYardLine || playData.post_yard_line || startPos;

      const yardsGained = DownDistanceCalculator.calculateNetYards(
        startPos,
        endPos,
        possessionLetter
      );

      const updatedDrive = {
        plays: (state.currentDrive?.plays || 0) + 1,
        yards: (state.currentDrive?.yards || 0) + (Number.isFinite(yardsGained) ? yardsGained : 0),
        startYardLine: state.currentDrive?.startYardLine || startPos,
        startTime: state.currentDrive?.startTime || '15:00',
        possessionTeam: current.possession || 'home'
      };

      dispatch({ type: 'UPDATE_DRIVE_STATS', payload: updatedDrive });
    } catch (e) {
      console.warn('updateDriveStats failed:', e);
    }
  };

  const updateGameClock = async (clockData) => {
    try {
      const response = await fetch(`${API_BASE}/update_game_clock.php`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(clockData)
      });

      if (!response.ok) throw new Error('Failed to update clock');
      
      const result = await response.json();
      if (result.updated_game_state) {
        dispatch({ type: 'SET_GAME_DATA', payload: result.updated_game_state });
      }
      
      return result;
    } catch (error) {
      console.error('Error updating clock:', error);
      dispatch({ type: 'SET_ERROR', payload: error.message });
      throw error;
    }
  };

  const initializeRosters = async (gameId) => {
    try {
      dispatch({ type: 'SET_SUBMITTING', payload: true });
      
      const response = await fetch(`${API_BASE}/initialize_rosters.php`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          game_id: gameId || state.gameData?.game_info?.game_id || 1000
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to initialize rosters');
      }
      
      const result = await response.json();
      
      // Refresh game state to get the updated rosters
      if (gameId || state.gameData?.game_info?.game_id) {
        await fetchGameState(gameId || state.gameData.game_info.game_id);
      }
      
      dispatch({ type: 'SET_SUBMITTING', payload: false });
      
      return result;
    } catch (error) {
      console.error('Error initializing rosters:', error);
      dispatch({ type: 'SET_ERROR', payload: error.message });
      dispatch({ type: 'SET_SUBMITTING', payload: false });
      throw error;
    }
  };

  const callTimeout = async (team, timeoutType = 'team') => {
    return submitEvent({
      event_type: 'TIMEOUT',
      team: team,
      timeout_type: timeoutType,
      play_type: 'GAME_CONTROL'
    });
  };

  const startNewDrive = async (team, startingYardLine = 25) => {
    // Initialize a new drive
    const newDrive = {
      plays: 0,
      yards: 0,
      startYardLine: `${team === 'home' ? 'Own' : 'Opp'} ${startingYardLine}`,
      startTime: state.gameData?.live_state?.time_remaining || '15:00',
      possessionTeam: team
    };
    
    dispatch({ type: 'SET_CURRENT_DRIVE', payload: newDrive });
    
    return submitEvent({
      event_type: 'NEW_DRIVE',
      team: team,
      starting_yard_line: startingYardLine,
      down: 1,
      distance: 10
    });
  };

  const adjustScore = async (team, points, scoreType) => {
    return submitEvent({
      event_type: 'SCORE_ADJUSTMENT',
      team: team,
      points: points,
      score_type: scoreType
    });
  };

  // Provide mock data for development
  const getMockGameState = () => ({
    game_info: {
      game_id: 'mock-game-1',
      home_team_name: 'Home Tigers',
      visitor_team_name: 'Away Eagles',
      home_team_id: 1,
      visitor_team_id: 2,
      game_date: new Date().toISOString(),
      venue: 'Memorial Stadium'
    },
    live_state: {
      game_status: 'in_progress',
      quarter: 1,
      time_remaining: 900, // 15:00
      possession: 'home',
      down: 1,
      distance: 10,
      yard_line: 25,
      home_score: 0,
      visitor_score: 0,
      home_timeouts: 3,
      visitor_timeouts: 3,
      play_clock: 40
    },
    recent_plays: [],
    team_stats: {
      home: {
        rushing_yards: 0,
        passing_yards: 0,
        total_yards: 0,
        first_downs: 0,
        penalties: 0,
        penalty_yards: 0,
        turnovers: 0
      },
      visitor: {
        rushing_yards: 0,
        passing_yards: 0,
        total_yards: 0,
        first_downs: 0,
        penalties: 0,
        penalty_yards: 0,
        turnovers: 0
      }
    },
    player_stats: {
      home: [],
      visitor: []
    },
    rosters: {
      home: [],
      visitor: []
    }
  });

  // Initialize with real data from database
  useEffect(() => {
    const loadGameData = async () => {
      try {
        // Get game ID from URL parameters
        const urlParams = new URLSearchParams(window.location.search);
        const gameId = urlParams.get('game_id') || '999'; // Default to '999' if no game_id in URL
        
        // Load game state from database API
        await fetchGameState(gameId);
      } catch (error) {
        console.error('Failed to load initial game state:', error);
        dispatch({ type: 'SET_ERROR', payload: 'Failed to load game data' });
      }
    };
    
    if (!state.gameData) {
      loadGameData();
    }
  }, []);

  // API Health Check Function
  const checkApiHealth = async () => {
    try {
      dispatch({ type: 'SET_API_STATUS', payload: 'connecting' });
      
      const response = await fetch('/strata_football/health_check.php', {
        method: 'GET',
        credentials: 'include',
        signal: AbortSignal.timeout(5000) // 5 second timeout
      });
      
      if (response.ok) {
        dispatch({ type: 'SET_API_STATUS', payload: 'connected' });
        return true;
      } else {
        dispatch({ type: 'SET_API_STATUS', payload: 'error' });
        return false;
      }
    } catch (error) {
      console.error('API health check failed:', error);
      dispatch({ type: 'SET_API_STATUS', payload: 'disconnected' });
      return false;
    }
  };

  // Run health check on mount and every 30 seconds
  useEffect(() => {
    checkApiHealth();
    const interval = setInterval(checkApiHealth, 30000);
    return () => clearInterval(interval);
  }, []);

  // Get current game ID from URL
  const getCurrentGameId = () => {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('game_id') || '999';
  };

  const contextValue = {
    ...state,
    gameState: state.gameData,  // Alias gameData as gameState for components
    apiStatus: state.apiStatus, // Include API status in context
    currentGameId: getCurrentGameId(),  // Get game ID from URL
    isLoading: state.isSubmitting,  // Map isSubmitting to isLoading for components
    fetchGameState,
    refetchGameState: () => fetchGameState(getCurrentGameId()), // Add refetch helper
    loadGameState: () => fetchGameState(getCurrentGameId()), // Add loadGameState helper
    submitEvent,
    updateGameClock,
    initializeRosters,
    callTimeout,
    startNewDrive,
    adjustScore,
    checkApiHealth, // Add health check function
    clearError: () => dispatch({ type: 'CLEAR_ERROR' }),
    setDebugGameId: (gameId) => dispatch({ type: 'SET_DEBUG_GAME_ID', payload: gameId }),
    toggleDebugMode: () => dispatch({ type: 'TOGGLE_DEBUG_MODE' }),
    loadDebugGame: async () => {
      if (state.debugGameId) {
        try {
          await fetchGameState(state.debugGameId);
        } catch (error) {
          console.error('Failed to load debug game:', error);
        }
      }
    }
  };

  return (
    <FootballGameContext.Provider value={contextValue}>
      {children}
    </FootballGameContext.Provider>
  );
}

export function useGameState() {
  const context = useContext(FootballGameContext);
  if (!context) {
    throw new Error('useGameState must be used within a FootballGameProvider');
  }
  return context;
}

export { FootballGameContext };
