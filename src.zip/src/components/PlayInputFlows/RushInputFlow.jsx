import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useGameState } from '../../contexts/FootballGameContext';
import usePlayerLookup from '../../hooks/usePlayerLookup';
import { offenseKey, defenseKey } from '../../utils/teamSide';
import JerseyNumberInput from '../JerseyNumberInput';
import PlayerDisambiguationModal from '../PlayerDisambiguationModal';
import YardlineInput from '../YardlineInput';
import PenaltyInputModal from '../PenaltyInputModal';

const RushInputFlow = ({ onComplete, onCancel, gameState }) => {
  const { submitEvent } = useGameState();
  const { findByJersey, pickBestCandidate } = usePlayerLookup(gameState);
  
  // Possession-aware team calculation
  const possession = gameState?.live_state?.possession || 'home';
  const offense = offenseKey(possession);   // 'home' | 'visitor'
  const defense = defenseKey(possession);
  const offenseName = offense === 'home' 
    ? (gameState?.game_info?.home_team_short || 'HOME') 
    : (gameState?.game_info?.visitor_team_short || 'VIS');
  const defenseName = defense === 'home'
    ? (gameState?.game_info?.home_team_short || 'HOME')
    : (gameState?.game_info?.visitor_team_short || 'VIS');

  console.debug('[RushInputFlow]', { possession, offense, defense });
  
  const gameId = gameState?.game_info?.game_id || 1000;
  
  const [rushData, setRushData] = useState({
    rusher: null,
    miscFumble: false,
    globalResult: null,
    tackler1: null,
    tackler2: null,
    finalYardLine: '',
    forcedBy: null,
    recoveringTeam: null,
    recoveringPlayer: null,
    recoverySpot: ''
  });

  // Jersey lookup state - new clean variables
  const [rusherJersey, setRusherJersey] = useState('');
  const [rusherCandidate, setRusherCandidate] = useState(null);
  const [rusherMatches, setRusherMatches] = useState([]);
  const [showDisambiguate, setShowDisambiguate] = useState(false);
  
  // Tackler state
  const [tackler1Jersey, setTackler1Jersey] = useState('');
  const [tackler2Jersey, setTackler2Jersey] = useState('');

  const [currentStep, setCurrentStep] = useState('rusher');
  const [errors, setErrors] = useState({});
  const [penaltyQueued, setPenaltyQueued] = useState(false);
  const [showPenaltyModal, setShowPenaltyModal] = useState(false);

  // Central "can proceed" guards
  const canProceedSelectRusher = !!rusherCandidate?.player_id;

  // Handle rusher lookup
  const handleRusherLookup = () => {
    if (!rusherJersey.trim()) {
      setErrors({ jersey: 'Enter a jersey number.' });
      return;
    }
    
    setErrors({});
    const matches = findByJersey(offense, rusherJersey);
    
    if (matches.length === 0) {
      // Create synthetic unknown player
      const unknown = { 
        player_id: `unknown-${offense}-${rusherJersey}`, 
        jersey: rusherJersey, 
        name: 'UNKNOWN PLAYER', 
        pos: 'RB' 
      };
      setRusherMatches([unknown]);
      setRusherCandidate(unknown);
      setCurrentStep('global-result');
      return;
    }
    
    if (matches.length === 1) {
      setRusherCandidate(matches[0]);
      setCurrentStep('global-result');
      return;
    }
    
    // Multiple matches
    setRusherMatches(matches);
    setShowDisambiguate(true);
  };

  // Disambiguation handlers
  const handleDisambigConfirm = (player) => {
    setRusherCandidate(player);
    setShowDisambiguate(false);
    setCurrentStep('global-result');
  };

  const handleDisambigCancel = () => {
    setShowDisambiguate(false);
  };

  // Clear player selection if jersey changes
  useEffect(() => {
    if (currentStep === 'rusher' && rusherCandidate) {
      setRusherCandidate(null);
      setRushData(prev => ({ ...prev, rusher: null }));
    }
  }, [rusherJersey]);

  // Handle keyboard shortcuts for global results (T, O, F, .) and penalty queuing (E)
  useEffect(() => {
    const handleKeyPress = (event) => {
      // Don't handle keyboard shortcuts if user is typing in an input field
      if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA' || event.target.tagName === 'SELECT') {
        return;
      }

      if (event.key === 'e' || event.key === 'E') {
        event.preventDefault();
        setPenaltyQueued(prev => !prev);
        console.log('Penalty queued state toggled:', !penaltyQueued);
      } else if (event.key === 'Enter') {
        event.preventDefault();
        handleEnterKeyPress();
      } else if (currentStep === 'global-result') {
        switch (event.key.toLowerCase()) {
          case 't':
            setRushData(prev => ({ ...prev, globalResult: 'tackle' }));
            setCurrentStep('tackle-details');
            break;
          case 'o':
            setRushData(prev => ({ ...prev, globalResult: 'out-of-bounds' }));
            setCurrentStep('out-of-bounds-details');
            break;
          case 'f':
            setRushData(prev => ({ ...prev, globalResult: 'fumble' }));
            setCurrentStep('fumble-details');
            break;
          case '.':
            setRushData(prev => ({ ...prev, globalResult: 'end-of-play' }));
            setCurrentStep('end-of-play-details');
            break;
        }
      }
      
      if (event.key === 'Escape') {
        onCancel();
      }
    };

    document.addEventListener('keydown', handleKeyPress);
    return () => document.removeEventListener('keydown', handleKeyPress);
  }, [currentStep, penaltyQueued, onCancel]);

  const handleEnterKeyPress = () => {
    switch (currentStep) {
      case 'rusher':
        if (canProceedSelectRusher) {
          setCurrentStep('global-result');
        } else {
          // Try to look up the jersey if not already selected
          if (rusherJersey.trim()) {
            handleJerseyLookup();
          } else {
            console.warn('[RUSH] Enter pressed but no jersey entered.');
          }
        }
        break;
      case 'global-result':
        // Result selection handled by keyboard shortcuts or buttons
        break;
      case 'tackle-details':
        if (rushData.tackler1 && rushData.finalYardLine) {
          handleSubmit();
        }
        break;
      case 'out-of-bounds-details':
        if (rushData.finalYardLine) {
          handleSubmit();
        }
        break;
      case 'fumble-details':
        if (rushData.recoveringTeam && rushData.recoveringPlayer && rushData.recoverySpot) {
          handleSubmit();
        }
        break;
      case 'end-of-play-details':
        if (rushData.finalYardLine) {
          handleSubmit();
        }
        break;
      default:
        break;
    }
  };

  const validateStep = (step) => {
    const newErrors = {};
    
    switch (step) {
      case 'rusher':
        if (!rushData.rusher?.id) {
          newErrors.rusher = 'Rusher selection is required';
        }
        break;
      case 'global-result':
        if (!rushData.globalResult) {
          newErrors.globalResult = 'Result selection is required';
        }
        break;
      case 'tackle-details':
        if (!rushData.tackler1) {
          newErrors.tackler1 = 'Primary tackler is required';
        }
        if (!rushData.finalYardLine) {
          newErrors.finalYardLine = 'Final yard line is required';
        }
        break;
      case 'out-of-bounds-details':
        if (!rushData.finalYardLine) {
          newErrors.finalYardLine = 'Final yard line is required';
        }
        break;
      case 'fumble-details':
        if (!rushData.recoveringTeam) {
          newErrors.recoveringTeam = 'Recovering team is required';
        }
        if (!rushData.recoveringPlayer) {
          newErrors.recoveringPlayer = 'Recovering player is required';
        }
        if (!rushData.recoverySpot) {
          newErrors.recoverySpot = 'Recovery spot is required';
        }
        break;
      case 'end-of-play-details':
        if (!rushData.finalYardLine) {
          newErrors.finalYardLine = 'Final yard line is required';
        }
        break;
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (!validateStep(currentStep)) return;
    
    switch (currentStep) {
      case 'rusher':
        setCurrentStep('global-result');
        break;
      case 'global-result':
        // This is handled by keyboard shortcuts or button clicks
        break;
      default:
        handleSubmit();
        break;
    }
  };

  const handleSubmit = async () => {
    console.debug('[RushInputFlow] submit', { currentStep, rusherCandidate, tackler1Jersey, finalYardLine: rushData.finalYardLine });
    
    if (!validateStep(currentStep)) return;
    
    // Handle synthetic unknown player
    const playerId = rusherCandidate?.player_id;
    const isUnknownPlayer = typeof playerId === 'string' && playerId.startsWith('unknown-');
    
    if (isUnknownPlayer) {
      console.warn('[RushInputFlow] Submitting with synthetic UNKNOWN PLAYER:', rusherCandidate);
    }
    
    // Build play data structure
    const playData = {
      play_type: 'rush',
      primary_player_id: isUnknownPlayer ? null : playerId,
      has_fumble: rushData.miscFumble || false,
      result: rushData.globalResult,
      end_yard_line: rushData.finalYardLine,
      penaltyQueued: penaltyQueued,
      
      // For unknown players, include jersey and name
      ...(isUnknownPlayer && {
        jersey: rusherCandidate.jersey,
        name: rusherCandidate.name
      }),
      
      // Tackler jerseys (will be resolved server-side)
      tackler1_jersey: tackler1Jersey,
      tackler2_jersey: tackler2Jersey,
      
      // Legacy participant data
      tackler1: rushData.tackler1,
      tackler2: rushData.tackler2,
      forcedBy: rushData.forcedBy,
      recoveringTeam: rushData.recoveringTeam,
      recoveringPlayer: rushData.recoveringPlayer,
      recoverySpot: rushData.recoverySpot
    };

    try {
      if (penaltyQueued) {
        setShowPenaltyModal(true);
        return;
      }

      await submitEvent(playData);
      onComplete(playData);
    } catch (error) {
      console.error('Error submitting rush play:', error);
      setErrors({ submit: 'Error submitting play. Please try again.' });
    }
  };

  const handlePenaltySubmit = async (penaltyData) => {
    try {
      // Submit play with penalty data
      const playData = {
        playType: 'rush',
        primary_player_id: rusherCandidate?.player_id ?? null,  // Updated to use rusherCandidate.player_id
        miscFumble: rushData.miscFumble,
        globalResult: rushData.globalResult,
        tackler1: rushData.tackler1,
        tackler2: rushData.tackler2,
        finalYardLine: rushData.finalYardLine,
        forcedBy: rushData.forcedBy,
        recoveringTeam: rushData.recoveringTeam,
        recoveringPlayer: rushData.recoveringPlayer,
        recoverySpot: rushData.recoverySpot,
        penalties: penaltyData.penalties
      };

      await submitPlayWithPenalties(playData, penaltyData);
      setShowPenaltyModal(false);
      setPenaltyQueued(false);
      onComplete(playData);
    } catch (error) {
      console.error('Error submitting play with penalties:', error);
      setErrors({ submit: 'Error submitting play with penalties. Please try again.' });
    }
  };

  const submitPlayWithPenalties = async (playData, penaltyData) => {
    const response = await fetch('/api/submit_play_enhanced.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        ...playData,
        penalties: penaltyData.penalties,
        penaltyEnforcement: penaltyData.enforcement
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return response.json();
  };

  const handleRusherEnter = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (canProceedSelectRusher) {
        setCurrentStep('global-result');
      } else {
        // Optional: auto-select the first exact jersey match when user typed a number
        console.warn('[RUSH] Enter pressed but rusher not selected.');
      }
    }
  };

  const handleNextFromRusher = () => {
    if (canProceedSelectRusher) {
      setCurrentStep('global-result');
    }
  };

  const renderRusherStep = () => (
    <div className="space-y-4">
      <h3 className="text-lg font-bold">Rush Play - Select Rusher</h3>
      
      <JerseyNumberInput
        label={`Rusher Jersey # (${offenseName.toLowerCase()} team)`}
        value={rusherJersey}
        onChange={setRusherJersey}
        onEnter={handleRusherLookup}
        autoFocus
      />

      <button
        type="button"
        className="btn-primary px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
        onClick={handleRusherLookup}
        disabled={!String(rusherJersey).trim()}
      >
        Next
      </button>

      {rusherCandidate && (
        <div className="p-2 bg-green-50 border border-green-200 rounded">
          <div className="font-medium text-green-800">
            Selected: {rusherCandidate.name} #{rusherCandidate.jersey}
          </div>
          <div className="text-sm text-green-600">
            {rusherCandidate.pos || rusherCandidate.position} {rusherCandidate.side ? `• ${rusherCandidate.side}` : ''}
          </div>
        </div>
      )}

      {errors.jersey && (
        <div className="p-2 bg-red-50 border border-red-200 rounded text-red-700 text-sm">
          {errors.jersey}
        </div>
      )}
      
      <div className="flex items-center space-x-2">
        <input
          type="checkbox"
          id="miscFumble"
          checked={rushData.miscFumble}
          onChange={(e) => setRushData(prev => ({ ...prev, miscFumble: e.target.checked }))}
          className="h-4 w-4"
        />
        <label htmlFor="miscFumble" className="text-sm">
          Misc Fumble (fumbled snap recovered by offense - affects fumble stat only)
        </label>
      </div>
      
      <div className="flex space-x-2">
        <button
          onClick={() => {
            if (rusherCandidate) {
              setCurrentStep('global-result');
            } else {
              handleJerseyLookup();
            }
          }}
          disabled={!rusherJersey.trim()}
          className="px-4 py-2 bg-blue-600 text-white rounded disabled:bg-gray-400"
        >
          {rusherCandidate ? 'Next' : 'Look Up Player'}
        </button>
        <button
          onClick={onCancel}
          className="px-4 py-2 bg-gray-500 text-white rounded"
        >
          Cancel
        </button>
      </div>
    </div>
  );

  const renderGlobalResultStep = () => (
    <div className="space-y-4">
      <h3 className="text-lg font-bold">
        Enter result for rush by #{rusherJersey} — {rusherCandidate?.name || 'Player'}
      </h3>
      
      <div className="text-sm text-gray-600 mb-4">
        Use keyboard shortcuts or click buttons:
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <button
          onClick={() => {
            setRushData(prev => ({ ...prev, globalResult: 'tackle' }));
            setCurrentStep('tackle-details');
          }}
          className="p-4 border-2 border-gray-300 rounded hover:border-blue-500 focus:border-blue-500"
        >
          <div className="font-bold">T - Tackle</div>
          <div className="text-sm text-gray-600">Player tackled at spot</div>
        </button>
        
        <button
          onClick={() => {
            setRushData(prev => ({ ...prev, globalResult: 'out-of-bounds' }));
            setCurrentStep('out-of-bounds-details');
          }}
          className="p-4 border-2 border-gray-300 rounded hover:border-blue-500 focus:border-blue-500"
        >
          <div className="font-bold">O - Out of Bounds</div>
          <div className="text-sm text-gray-600">Player went out of bounds</div>
        </button>
        
        <button
          onClick={() => {
            setRushData(prev => ({ ...prev, globalResult: 'fumble' }));
            setCurrentStep('fumble-details');
          }}
          className="p-4 border-2 border-gray-300 rounded hover:border-blue-500 focus:border-blue-500"
        >
          <div className="font-bold">F - Fumble</div>
          <div className="text-sm text-gray-600">Ball was fumbled during play</div>
        </button>
        
        <button
          onClick={() => {
            setRushData(prev => ({ ...prev, globalResult: 'end-of-play' }));
            setCurrentStep('end-of-play-details');
          }}
          className="p-4 border-2 border-gray-300 rounded hover:border-blue-500 focus:border-blue-500"
        >
          <div className="font-bold">. - End of Play</div>
          <div className="text-sm text-gray-600">Play completed without special circumstances</div>
        </button>
      </div>
      
      <button
        onClick={() => setCurrentStep('rusher')}
        className="px-4 py-2 bg-gray-500 text-white rounded"
      >
        Back
      </button>
    </div>
  );

  const renderTackleDetails = () => {
    const defenseRoster = gameState?.rosters?.[defense] || [];
    const showRosterHint = defenseRoster.length === 0;
    
    return (
      <div className="space-y-4">
        <h3 className="text-lg font-bold">Rush Play - Tackle Details</h3>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Primary Tackler Jersey # <span className="inline-block px-1 py-0.5 text-xs bg-gray-200 rounded">{defenseName}</span>
          </label>
          <input
            value={tackler1Jersey}
            onChange={e => setTackler1Jersey(e.target.value.replace(/\D+/g,''))}
            inputMode="numeric"
            pattern="[0-9]*"
            placeholder="Enter jersey number"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          />
          {showRosterHint && (
            <p className="text-xs text-gray-500 mt-1">
              No roster data available for {defenseName}
            </p>
          )}
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Assist Tackler Jersey # (Optional) <span className="inline-block px-1 py-0.5 text-xs bg-gray-200 rounded">{defenseName}</span>
          </label>
          <input
            value={tackler2Jersey}
            onChange={e => setTackler2Jersey(e.target.value.replace(/\D+/g,''))}
            inputMode="numeric"
            pattern="[0-9]*"
            placeholder="Enter jersey number"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        
        <YardlineInput
          label="Final Yard Line (where tackled)"
          value={rushData.finalYardLine}
          onChange={(yardLine) => {
            setRushData(prev => ({ ...prev, finalYardLine: yardLine }));
          }}
          onKeyDown={e => e.stopPropagation()}
          error={errors.finalYardLine}
          gameId={gameState?.game_info?.game_id || 1000}
          autoFocus={true}
          required
        />
        
        <div className="flex space-x-2">
          <button
            onClick={handleSubmit}
            disabled={!tackler1Jersey || !rushData.finalYardLine}
            className="px-4 py-2 bg-green-600 text-white rounded disabled:bg-gray-400"
          >
            Submit Play
          </button>
          <button
            onClick={() => setCurrentStep('global-result')}
            className="px-4 py-2 bg-gray-500 text-white rounded"
          >
            Back
          </button>
          <button
            onClick={onCancel}
            className="px-4 py-2 bg-gray-500 text-white rounded"
          >
            Cancel
          </button>
        </div>
      </div>
    );
  };

  const renderOutOfBoundsDetails = () => (
    <div className="space-y-4">
      <h3 className="text-lg font-bold">Rush Play - Out of Bounds Details</h3>
      
      <PlayerInput
        label="Tackler (Optional - if forced out)"
        value={rushData.tackler1}
        onChange={(player) => setRushData(prev => ({ ...prev, tackler1: player }))}
        gameId={gameState?.game_info?.game_id || 1000}
        team={gameState?.live_state?.possession === 'home' ? 'visitor' : 'home'}
      />
      
      <YardlineInput
        label="Final Yard Line (where went out of bounds)"
        value={rushData.finalYardLine}
        onChange={(yardLine) => setRushData(prev => ({ ...prev, finalYardLine: yardLine }))}
        error={errors.finalYardLine}
        gameId={gameState?.game_info?.game_id || 1000}
        required
      />
      
      <div className="flex space-x-2">
        <button
          onClick={handleSubmit}
          disabled={!rushData.finalYardLine}
          className="px-4 py-2 bg-green-600 text-white rounded disabled:bg-gray-400"
        >
          Submit Play
        </button>
        <button
          onClick={() => setCurrentStep('global-result')}
          className="px-4 py-2 bg-gray-500 text-white rounded"
        >
          Back
        </button>
        <button
          onClick={onCancel}
          className="px-4 py-2 bg-gray-500 text-white rounded"
        >
          Cancel
        </button>
      </div>
    </div>
  );

  const renderFumbleDetails = () => (
    <div className="space-y-4">
      <h3 className="text-lg font-bold">Rush Play - Fumble Details</h3>
      
      <PlayerInput
        label="Forced By"
        value={rushData.forcedBy}
        onChange={(player) => setRushData(prev => ({ ...prev, forcedBy: player }))}
        gameState={gameState}
      />
      
      <div className="space-y-2">
        <label className="block font-bold">Recovering Team</label>
        <div className="flex space-x-4">
          <button
            onClick={() => setRushData(prev => ({ ...prev, recoveringTeam: 'home' }))}
            className={`px-4 py-2 rounded ${rushData.recoveringTeam === 'home' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
          >
            Home
          </button>
          <button
            onClick={() => setRushData(prev => ({ ...prev, recoveringTeam: 'visitor' }))}
            className={`px-4 py-2 rounded ${rushData.recoveringTeam === 'visitor' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
          >
            Visitor
          </button>
        </div>
        {errors.recoveringTeam && <div className="text-red-500 text-sm">{errors.recoveringTeam}</div>}
      </div>
      
      <PlayerInput
        label="Recovering Player"
        value={rushData.recoveringPlayer}
        onChange={(player) => setRushData(prev => ({ ...prev, recoveringPlayer: player }))}
        error={errors.recoveringPlayer}
        gameState={gameState}
        required
      />
      
      <YardlineInput
        label="Recovery Spot"
        value={rushData.recoverySpot}
        onChange={(recoverySpot) => setRushData(prev => ({ ...prev, recoverySpot }))}
        error={errors.recoverySpot}
        gameState={gameState}
        required
      />
      
      <div className="text-sm text-gray-600">
        Note: After fumble recovery, you'll be prompted for the final result of the play.
      </div>
      
      <div className="flex space-x-2">
        <button
          onClick={handleSubmit}
          disabled={!rushData.recoveringTeam || !rushData.recoveringPlayer || !rushData.recoverySpot}
          className="px-4 py-2 bg-green-600 text-white rounded disabled:bg-gray-400"
        >
          Submit Play
        </button>
        <button
          onClick={() => setCurrentStep('global-result')}
          className="px-4 py-2 bg-gray-500 text-white rounded"
        >
          Back
        </button>
        <button
          onClick={onCancel}
          className="px-4 py-2 bg-gray-500 text-white rounded"
        >
          Cancel
        </button>
      </div>
    </div>
  );

  const renderEndOfPlayDetails = () => (
    <div className="space-y-4">
      <h3 className="text-lg font-bold">Rush Play - End of Play</h3>
      
      <YardlineInput
        label="Final Yard Line"
        value={rushData.finalYardLine}
        onChange={(yardLine) => setRushData(prev => ({ ...prev, finalYardLine: yardLine }))}
        error={errors.finalYardLine}
        gameState={gameState}
        required
      />
      
      <div className="text-sm text-gray-600">
        <div>Special handling:</div>
        <div>• Own 00 (0 Relative YL) = Safety</div>
        <div>• Opp 00 (100 Relative YL) = Touchdown</div>
      </div>
      
      <div className="flex space-x-2">
        <button
          onClick={handleSubmit}
          disabled={!rushData.finalYardLine}
          className="px-4 py-2 bg-green-600 text-white rounded disabled:bg-gray-400"
        >
          Submit Play
        </button>
        <button
          onClick={() => setCurrentStep('global-result')}
          className="px-4 py-2 bg-gray-500 text-white rounded"
        >
          Back
        </button>
        <button
          onClick={onCancel}
          className="px-4 py-2 bg-gray-500 text-white rounded"
        >
          Cancel
        </button>
      </div>
      
      {errors.submit && <div className="text-red-500 text-sm">{errors.submit}</div>}
    </div>
  );

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 'rusher':
        return renderRusherStep();
      case 'global-result':
        return renderGlobalResultStep();
      case 'tackle-details':
        return renderTackleDetails();
      case 'out-of-bounds-details':
        return renderOutOfBoundsDetails();
      case 'fumble-details':
        return renderFumbleDetails();
      case 'end-of-play-details':
        return renderEndOfPlayDetails();
      default:
        return renderRusherStep();
    }
  };

  return (
    <div className="p-6 bg-white border border-gray-300 rounded-lg shadow-lg max-w-2xl">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="mb-4 p-3 bg-blue-100 border-l-4 border-blue-500 text-blue-800">
          <div className="flex items-center">
            <span className="text-lg mr-2">ℹ️</span>
            <span className="text-sm">{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Debug: Show penalty state */}
      <div className="mb-2 text-xs text-gray-500">
        Debug: penaltyQueued = {penaltyQueued ? 'true' : 'false'}
      </div>
      
      {/* Penalty Queued Indicator */}
      {penaltyQueued && (
        <div className="mb-4 p-3 bg-yellow-200 border-l-4 border-yellow-500 text-yellow-800">
          <div className="flex items-center">
            <span className="text-lg mr-2">⚠️</span>
            <span className="font-semibold">PENALTY QUEUED</span>
            <span className="ml-2 text-sm">(Press E to toggle)</span>
          </div>
        </div>
      )}
      
      {renderCurrentStep()}
      
      {/* Player Disambiguation Modal */}
      {/* Player Disambiguation Modal */}
      <PlayerDisambiguationModal
        isOpen={showDisambiguate}
        jersey={rusherJersey}
        candidates={rusherMatches}
        defaultSelection={pickBestCandidate(rusherMatches)}
        onConfirm={handleDisambigConfirm}
        onCancel={handleDisambigCancel}
      />

      {/* Penalty Input Modal */}
      {showPenaltyModal && (
        <PenaltyInputModal
          isOpen={showPenaltyModal}
          onClose={() => setShowPenaltyModal(false)}
          onSubmit={handlePenaltySubmit}
          gameState={gameState}
        />
      )}
    </div>
  );
};

export default RushInputFlow;
