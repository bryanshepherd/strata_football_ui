import React, { useState } from 'react';
import { useGameState } from '../../contexts/FootballGameContext';
import PenaltyModal from '../PenaltyModal';

const PenaltyInputFlow = ({ onComplete, onCancel, gameState }) => {
  const { submitEvent } = useGameState();
  const [showPenaltyModal, setShowPenaltyModal] = useState(true);

  const handlePenaltySubmit = async (penaltyData) => {
    try {
      // Convert penalty data to event format for submission
      const eventData = {
        event_type: 'penalty',
        penalty_type: penaltyData.penalty.PenaltyName,
        penalty_code: penaltyData.penalty.PenaltyCode,
        penalty_team: penaltyData.team,
        penalty_player: penaltyData.playerNumber,
        penalty_result: penaltyData.result,
        penalty_yards: penaltyData.result === 'A' ? 
          (penaltyData.penalty.YardsNCAA || penaltyData.penalty.YardsHS) : 0,
        enforcement_mode: penaltyData.enforcement?.enforcementMode,
        enforced_from: penaltyData.enforcement?.enforcedFrom,
        final_spot: penaltyData.enforcement?.finalSpot,
        first_down_mode: penaltyData.enforcement?.firstDownMode,
        ejected: penaltyData.enforcement?.ejected || false,
        has_penalty: true
      };

      console.log('Submitting penalty event:', eventData);

      const result = await submitEvent(eventData);
      
      if (result) {
        onComplete(result);
      } else {
        throw new Error('Failed to submit penalty');
      }
    } catch (error) {
      console.error('Error submitting penalty:', error);
      alert(`Error submitting penalty: ${error.message}`);
    }
  };

  const handleModalClose = () => {
    setShowPenaltyModal(false);
    onCancel();
  };

  return (
    <div className="p-4">
      <PenaltyModal
        isOpen={showPenaltyModal}
        onClose={handleModalClose}
        onSubmit={handlePenaltySubmit}
        gameState={gameState}
      />
      
      {!showPenaltyModal && (
        <div className="text-center">
          <p className="text-gray-600 mb-4">Penalty input cancelled</p>
          <button
            onClick={() => setShowPenaltyModal(true)}
            className="px-4 py-2 bg-yellow-600 text-white rounded hover:bg-yellow-700"
          >
            Reopen Penalty Input
          </button>
        </div>
      )}
    </div>
  );
};

export default PenaltyInputFlow;
