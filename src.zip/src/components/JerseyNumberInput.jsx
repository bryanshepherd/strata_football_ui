import React, { useState, useEffect, useRef } from 'react';

export default function JerseyNumberInput({ label = 'Jersey #', value, onChange, autoFocus=true, onEnter }) {
  const [local, setLocal] = useState(value ?? '');
  const ref = useRef(null);

  useEffect(() => { if (autoFocus && ref.current) ref.current.focus(); }, [autoFocus]);

  useEffect(() => { setLocal(value ?? ''); }, [value]);

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <input
        ref={ref}
        type="text"
        inputMode="numeric"
        pattern="[0-9]*"
        className="w-full border rounded px-3 py-2"
        placeholder="Enter jersey number"
        value={local}
        onChange={(e) => {
          const v = e.target.value.replace(/[^0-9]/g,'');
          setLocal(v);
          onChange?.(v);
        }}
        onKeyDown={(e) => {
          if (e.key === 'Enter') onEnter?.(local);
          if (e.key === 'Escape') ref.current?.blur();
        }}
      />
    </div>
  );
}
