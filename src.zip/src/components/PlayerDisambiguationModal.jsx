import React from 'react';

export default function PlayerDisambiguationModal({ isOpen, matches, defaultIndex = 0, onChoose, onCancel }) {
  if (!isOpen) return null;
  const safeIndex = Number.isInteger(defaultIndex) ? defaultIndex : 0;
  
  const formatPositions = (match) => {
    const positions = [];
    if (match.off_position) positions.push(`OFF: ${match.off_position}`);
    if (match.def_position) positions.push(`DEF: ${match.def_position}`);
    if (match.st_position) positions.push(`ST: ${match.st_position}`);
    
    // Fallback to legacy position if no specific positions
    if (positions.length === 0 && match.position) {
      positions.push(match.position);
    }
    
    return positions.length > 0 ? positions.join(' • ') : '—';
  };
  
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg p-4 w-[480px]">
        <h3 className="text-lg font-semibold mb-2">Select Player</h3>
        <p className="text-sm text-gray-600 mb-3">Multiple players wear jersey #{matches[0]?.jersey}. Choose the correct one:</p>
        <ul className="divide-y border rounded">
          {matches.map((m, i) => (
            <li key={`${m.player_id}-${i}`} className="p-3 flex items-center justify-between">
              <div className="flex-1">
                <div className="font-medium">{m.name} <span className="text-gray-500">#{m.jersey}</span></div>
                <div className="text-xs text-gray-500">{formatPositions(m)}</div>
                {m.side && <div className="text-xs text-blue-600">{m.side}</div>}
              </div>
              <button
                autoFocus={i === safeIndex}
                className="px-3 py-1 text-sm rounded bg-blue-600 text-white hover:bg-blue-700 ml-3"
                onClick={() => onChoose(m)}
              >
                Select
              </button>
            </li>
          ))}
        </ul>
        <div className="mt-3 text-right">
          <button className="text-sm text-gray-600 hover:text-gray-800" onClick={onCancel}>Cancel</button>
        </div>
      </div>
    </div>
  );
}
