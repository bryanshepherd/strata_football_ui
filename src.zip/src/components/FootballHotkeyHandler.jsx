import React, { useEffect } from 'react';
import { useFootballFlow } from '../contexts/FootballFlowContext';

export default function FootballHotkeyHandler() {
  const { startFlow, currentFlow, isModalOpen } = useFootballFlow();

  useEffect(() => {
    const handleKeyPress = (e) => {
      // Don't handle hotkeys if modal is open or if typing in an input
      if (isModalOpen || e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
        return;
      }

      // Main play type hotkeys - R, P, U, K, A, E, G
      switch (e.key.toLowerCase()) {
        case 'r':
          e.preventDefault();
          startFlow('rush');
          break;
        case 'p':
          e.preventDefault();
          startFlow('pass');
          break;
        case 'u':
          e.preventDefault();
          startFlow('punt');
          break;
        case 'k':
          e.preventDefault();
          startFlow('kick');
          break;
        case 'a':
          // PAT flow - only available after touchdown
          // TODO: Add touchdown detection logic
          e.preventDefault();
          startFlow('pat');
          break;
        case 'e':
          e.preventDefault();
          startFlow('penalty');
          break;
        case 'g':
          e.preventDefault();
          startFlow('gamecontrol');
          break;
        case 'escape':
          // Escape key handled by individual flow components
          break;
        default:
          // Other keys handled by specific flow components
          break;
      }
    };

    document.addEventListener('keydown', handleKeyPress);
    return () => document.removeEventListener('keydown', handleKeyPress);
  }, [startFlow, isModalOpen]);

  // This component doesn't render anything visible
  return null;
}
