# Patch Suggestions - API Field Consistency Fixes

## Overview
This document provides specific code patches to fix the field consistency issues identified in the Frontend vs Backend API analysis.

**Analysis Date**: August 26, 2025  
**Target Files**: `src/utils/apiDataContract.ts`, documentation files, test files

## High Priority Patches

### 1. Filter Frontend-Only Fields
**File**: `src/utils/apiDataContract.ts`  
**Issue**: Frontend-only fields being sent to backend causing potential errors  
**Priority**: High

```typescript
// Add this method to DataTransformer class
/**
 * Remove frontend-only fields before sending to backend
 */
static cleanForBackend(data: any): any {
  // Remove frontend-only fields that have no backend equivalent
  const {
    tertiaryPlayerID,
    playContext,
    newContext,
    ...cleanedData
  } = data;

  // Handle penalty arrays - remove frontend-only penalty fields
  if (Array.isArray(cleanedData.penalties)) {
    cleanedData.penalties = cleanedData.penalties.map(penalty => {
      const { spot, ...cleanedPenalty } = penalty;
      return cleanedPenalty;
    });
  }

  return cleanedData;
}

// Update frontendToBackend method
static frontendToBackend(frontendData: any): any {
  // Clean frontend-only fields first
  const cleanedData = this.cleanForBackend(frontendData);
  
  const transformed: any = {
    // Core game state mappings - backend fields take precedence
    period: cleanedData.period || cleanedData.quarter,
    time_remaining: cleanedData.time_remaining || this.clockToSeconds(cleanedData.clock || cleanedData.timeRemaining),
    // ... rest of existing transformations
  };
  
  // ... rest of existing method
}
```

### 2. Add Field Validation
**File**: `src/utils/apiDataContract.ts`  
**Issue**: No validation for field formats and types  
**Priority**: High

```typescript
// Add to DataValidator class
/**
 * Validate field formats before transformation
 */
static validateFieldFormats(data: any): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  // Validate time formats
  if (data.clock && !this.isValidTimeFormat(data.clock)) {
    errors.push(`Invalid clock format: ${data.clock}. Expected MM:SS or seconds number`);
  }

  // Validate possession format
  if (data.possession && !['H', 'V', 'home', 'visitor'].includes(data.possession)) {
    errors.push(`Invalid possession: ${data.possession}. Expected H, V, home, or visitor`);
  }

  // Validate yard line format
  if (data.yardLinePosition && !this.isValidYardLine(data.yardLinePosition)) {
    errors.push(`Invalid yard line: ${data.yardLinePosition}. Expected H##, V##, or 50`);
  }

  // Validate down range
  if (data.down && (data.down < 1 || data.down > 4)) {
    errors.push(`Invalid down: ${data.down}. Must be 1-4`);
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Validate time format (string or number)
 */
private static isValidTimeFormat(time: any): boolean {
  if (typeof time === 'number') {
    return time >= 0 && time <= 3600; // 0 to 60 minutes in seconds
  }
  if (typeof time === 'string') {
    return /^\d{1,2}:\d{2}$/.test(time);
  }
  return false;
}

/**
 * Validate yard line format
 */
private static isValidYardLine(yardLine: string): boolean {
  if (!yardLine) return false;
  if (yardLine === '50') return true;
  const match = /^([HV])(\d{2})$/.exec(yardLine);
  if (!match) return false;
  const yards = parseInt(match[2], 10);
  return yards >= 0 && yards <= 50;
}
```

## Medium Priority Patches

### 3. Standardize Result/ResultCode Handling
**File**: `src/utils/apiDataContract.ts`  
**Issue**: Confusion between 'result' and 'resultCode' fields  
**Priority**: Medium

```typescript
// Update transformPlayData method
static transformPlayData(frontendData: any): any {
  const transformed: any = {
    // Standardize on 'result' for backend (BE expects 'result')
    result: frontendData.result || frontendData.resultCode,
    
    // ... rest of transformations
  };
  
  // Remove the old bidirectional mapping
  // OLD: result: frontendData.resultCode || frontendData.result,
  
  return transformed;
}

// Update backendToFrontend method  
static backendToFrontend(backendData: any): any {
  const transformed: any = {
    // Standardize on 'resultCode' for frontend
    resultCode: backendData.result || backendData.resultCode,
    
    // ... rest of transformations
  };
  
  return transformed;
}

// Add deprecation warning (temporary)
static warnDeprecatedFields(data: any): void {
  if (data.resultCode && data.result) {
    console.warn('Both result and resultCode present. Using result for backend compatibility.');
  }
}
```

### 4. Improve Player Data Case Consistency
**File**: `src/utils/apiDataContract.ts`  
**Issue**: Inconsistent casing for player/team data  
**Priority**: Medium

```typescript
// Add player data normalization
/**
 * Normalize player data casing for consistency
 */
static normalizePlayerData(playerData: any): any {
  if (!playerData) return playerData;
  
  return {
    // Standardize on snake_case for backend compatibility
    player_id: playerData.player_id || playerData.PlayerID || playerData.playerId,
    jersey_number: playerData.jersey_number || playerData.JerseyNumber,
    first_name: playerData.first_name || playerData.FirstName || playerData.firstName,
    last_name: playerData.last_name || playerData.LastName || playerData.lastName,
    name: playerData.name || playerData.Name,
    
    // Preserve other fields
    ...Object.fromEntries(
      Object.entries(playerData).filter(([key]) => 
        !['player_id', 'PlayerID', 'playerId', 'jersey_number', 'JerseyNumber', 
          'first_name', 'FirstName', 'firstName', 'last_name', 'LastName', 'lastName',
          'name', 'Name'].includes(key)
      )
    )
  };
}

// Add to roster data transformation
static normalizeRosterData(rosters: any): any {
  if (!rosters) return rosters;
  
  return {
    home: Array.isArray(rosters.home) 
      ? rosters.home.map(player => this.normalizePlayerData(player))
      : rosters.home,
    visitor: Array.isArray(rosters.visitor)
      ? rosters.visitor.map(player => this.normalizePlayerData(player))
      : rosters.visitor
  };
}
```

### 5. Consolidate Penalty Field Mappings
**File**: `src/utils/apiDataContract.ts`  
**Issue**: Confusing penalty field name differences  
**Priority**: Medium

```typescript
// Create explicit penalty field mapping
static readonly PENALTY_FIELD_MAP = {
  // Frontend → Backend
  team: 'penalized_team',
  code: 'penalty_type', 
  yards: 'yards_enforced',
  enforcedFrom: 'enforced_from',
  automaticFirstDown: 'automatic_first_down',
  lossOfDown: 'loss_of_down',
  liveBall: 'live_ball',
  carryOverToKO: 'carry_over_to_ko',
  accepted: 'is_accepted'
} as const;

/**
 * Transform penalty array with explicit field mapping
 */
static transformPenaltyArray(penalties: any[]): any[] {
  if (!Array.isArray(penalties)) return penalties;
  
  return penalties.map(penalty => {
    const transformed: any = {};
    
    // Use explicit mapping for clarity
    Object.entries(this.PENALTY_FIELD_MAP).forEach(([feField, beField]) => {
      if (penalty.hasOwnProperty(feField)) {
        transformed[beField] = penalty[feField];
      }
    });
    
    // Handle special cases
    if (penalty.team && ['home', 'visitor'].includes(penalty.team)) {
      transformed.penalized_team = penalty.team === 'home' ? 'H' : 'V';
    }
    
    return transformed;
  });
}
```

## Low Priority Patches

### 6. Add Comprehensive Documentation
**File**: `src/utils/apiDataContract.ts`  
**Issue**: Insufficient JSDoc documentation for transformations  
**Priority**: Low

```typescript
/**
 * STRATA FOOTBALL - API DATA CONTRACT STANDARDS
 * 
 * This module provides standardized data transformation between frontend and backend.
 * 
 * Key Transformation Patterns:
 * 1. camelCase (FE) ↔ snake_case (BE)
 * 2. Time formats: "MM:SS" string ↔ seconds number (BE accepts both)
 * 3. Possession: 'H'/'V' ↔ 'home'/'visitor' (BE accepts both)
 * 4. Field name mappings: quarter→period, clock→timeRemaining, etc.
 * 
 * @example
 * // Transform frontend data for backend submission
 * const backendData = DataTransformer.frontendToBackend({
 *   quarter: 2,
 *   clock: "12:30",
 *   possession: "home",
 *   playType: "rush"
 * });
 * // Result: { period: 2, time_remaining: 750, possession: "H", play_type: "rush" }
 */

/**
 * Convert frontend data to backend format (snake_case)
 * 
 * Handles the following transformations:
 * - quarter → period
 * - clock → time_remaining (with format conversion)  
 * - distance → yardsToGo
 * - spot → yardLinePosition
 * - isScoringPlay → is_scoring_play
 * - Penalty arrays with field name mapping
 * 
 * @param frontendData - Frontend camelCase data
 * @returns Backend snake_case data
 * 
 * @example
 * const result = DataTransformer.frontendToBackend({
 *   quarter: 1,
 *   clock: "15:00", 
 *   playType: "pass",
 *   yardsGained: 12,
 *   isScoringPlay: true
 * });
 */
static frontendToBackend(frontendData: any): any {
  // ... existing implementation with better comments
}
```

### 7. Add Unit Tests for All Transformations
**File**: `tests/apiDataContract.test.ts` (create if not exists)  
**Issue**: Insufficient test coverage for transformations  
**Priority**: Low

```typescript
import { DataTransformer, DataValidator } from '../src/utils/apiDataContract';

describe('DataTransformer', () => {
  describe('frontendToBackend', () => {
    test('transforms game state fields correctly', () => {
      const input = {
        quarter: 2,
        clock: "12:30",
        possession: "home",
        distance: 7,
        spot: "H35"
      };
      
      const result = DataTransformer.frontendToBackend(input);
      
      expect(result).toEqual({
        period: 2,
        time_remaining: 750, // 12*60 + 30
        possession: "H",
        distance: 7,
        yard_line: "H35"
      });
    });
    
    test('handles time format conversion', () => {
      expect(DataTransformer.clockToSeconds("15:00")).toBe(900);
      expect(DataTransformer.clockToSeconds("0:30")).toBe(30);
      expect(DataTransformer.clockToSeconds(600)).toBe(600);
    });
    
    test('transforms penalty arrays correctly', () => {
      const input = {
        penalties: [{
          team: 'home',
          code: 'HOLD',
          yards: 10,
          enforcedFrom: 'previous',
          accepted: true
        }]
      };
      
      const result = DataTransformer.frontendToBackend(input);
      
      expect(result.penalties[0]).toEqual({
        penalized_team: 'H',
        penalty_type: 'HOLD', 
        yards_enforced: 10,
        enforced_from: 'previous',
        is_accepted: true
      });
    });
    
    test('filters out frontend-only fields', () => {
      const input = {
        playType: 'rush',
        tertiaryPlayerID: 123,
        playContext: 'H,1,10,H25',
        newContext: 'H,2,5,H30'
      };
      
      const result = DataTransformer.frontendToBackend(input);
      
      expect(result.play_type).toBe('rush');
      expect(result.tertiaryPlayerID).toBeUndefined();
      expect(result.playContext).toBeUndefined();
      expect(result.newContext).toBeUndefined();
    });
  });
  
  describe('DataValidator', () => {
    test('validates time formats', () => {
      expect(DataValidator.validateFieldFormats({ clock: "15:00" }).valid).toBe(true);
      expect(DataValidator.validateFieldFormats({ clock: 900 }).valid).toBe(true);
      expect(DataValidator.validateFieldFormats({ clock: "25:00" }).valid).toBe(false);
      expect(DataValidator.validateFieldFormats({ clock: "invalid" }).valid).toBe(false);
    });
    
    test('validates possession values', () => {
      expect(DataValidator.validateFieldFormats({ possession: "H" }).valid).toBe(true);
      expect(DataValidator.validateFieldFormats({ possession: "home" }).valid).toBe(true);
      expect(DataValidator.validateFieldFormats({ possession: "invalid" }).valid).toBe(false);
    });
  });
});
```

## Documentation Patches

### 8. Update API Documentation
**File**: `documentation/php-02-Endpoints-and-Contracts.md`  
**Issue**: Time format documentation unclear  
**Priority**: Medium

```markdown
#### Time Format Handling

The backend accepts **both** time formats for flexibility:

| Format | Type | Example | Usage |
|--------|------|---------|--------|
| MM:SS String | `string` | `"12:30"` | Human-readable, preferred for display |
| Seconds Number | `number` | `750` | Numeric calculations, internal processing |

**Request Examples:**
```json
// Both are valid
{ "time_remaining": "12:30" }
{ "time_remaining": 750 }
```

**Response Format:**
Backend responses use seconds (number) for consistency in calculations.
```json
{ "time_remaining": 750 }
```
```

### 9. Update Frontend Documentation  
**File**: `documentation/02-GameState-and-DataContracts.md`  
**Issue**: Field mapping documentation incomplete  
**Priority**: Medium

```markdown
## Field Mapping Reference

### Complete Frontend ↔ Backend Mapping Table

| Frontend Field | Backend Field | Type Conversion | Notes |
|----------------|---------------|-----------------|--------|
| `quarter` | `period` | `number` → `number` | 1-4 quarters, 5+ overtime |
| `clock` | `time_remaining` | `"MM:SS"` → `number` | Converted to seconds |
| `possession` | `possession` | `'home'/'visitor'` → `'H'/'V'` | Normalized format |
| `distance` | `yardsToGo` | `number` → `number` | Yards to first down |
| `spot` | `yardLinePosition` | `string` → `string` | Field position |
| `resultCode` | `result` | `string` → `string` | Play result code |
| `yardsGained` | `yards` | `number` → `number` | Net yards |
| `isScoringPlay` | `is_scoring_play` | `boolean` → `boolean` | Scoring flag |

### Frontend-Only Fields

These fields exist only in the frontend and are filtered out before backend submission:

- `tertiaryPlayerID` - Additional player reference
- `playContext` - Context string (format: "H,1,10,H25") 
- `newContext` - Post-play context string
- `penalties[].spot` - Penalty spot information
```

## Implementation Priority

### Sprint 1 (High Priority)
1. **Frontend-only field filtering** - Prevents backend errors
2. **Field validation** - Catches format issues early
3. **Documentation updates** - Clarifies time format handling

### Sprint 2 (Medium Priority)  
1. **Result/ResultCode standardization** - Reduces confusion
2. **Player data case consistency** - Improves data reliability
3. **Penalty field mapping consolidation** - Clearer transformations

### Sprint 3 (Low Priority)
1. **Comprehensive unit tests** - Ensures transformation reliability
2. **Enhanced JSDoc documentation** - Improves developer experience
3. **Statistics field name improvements** - Better clarity

## Testing Strategy

### Unit Tests Required
- [ ] Field filtering (frontend-only removal)
- [ ] Time format conversions (string ↔ number)
- [ ] Possession format conversions ('H'/'V' ↔ 'home'/'visitor')
- [ ] Penalty array transformations
- [ ] Player data case normalization
- [ ] Validation functions

### Integration Tests Required
- [ ] Full play submission round-trip
- [ ] Game state load/save cycle
- [ ] Error handling for invalid formats
- [ ] Backward compatibility with existing data

## Rollback Plan

If any patches cause issues:

1. **Immediate rollback**: Revert transformer changes
2. **Gradual deployment**: Feature flag new validation
3. **Backward compatibility**: Maintain old field support during transition
4. **Monitoring**: Track transformation errors in production

---

**Implementation Owner**: Frontend Team  
**Review Required**: Backend Team (for field mapping changes)  
**Timeline**: 3 sprints (6 weeks)  
**Risk Level**: Medium (system works, improvements for consistency)