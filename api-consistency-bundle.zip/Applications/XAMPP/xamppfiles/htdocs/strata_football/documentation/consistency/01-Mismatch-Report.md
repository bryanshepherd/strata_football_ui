# Field Mismatch Report - Frontend vs Backend API Consistency

## Executive Summary

**Analysis Date**: August 26, 2025  
**Total Fields Analyzed**: 96  
**Overall Consistency**: 77% equivalent, 23% requiring attention

### Summary Counts
- ✅ **Equivalent Fields**: 74 (77%)
- 🧪 **Behavioral Mismatches**: 18 (19%) 
- ⛔ **Blocking Mismatches**: 4 (4%)
- ⚠️ **Doc-only Mismatches**: 0 (0%)

## Critical Blocking Mismatches ⛔

These mismatches prevent proper data flow and must be addressed:

### 1. Frontend-Only Fields
**Impact**: Data loss when sending to backend

| Field | Location | FE Type | Issue | Fix Required |
|-------|----------|---------|--------|-------------|
| `tertiaryPlayerID` | Play data | `number` | Not supported by backend | Remove or map to backend field |
| `playContext` | Play data | `string` | Frontend convenience field | Document as FE-only or add BE support |
| `newContext` | Play data | `string` | Frontend convenience field | Document as FE-only or add BE support |
| `spot` (penalty) | Penalty data | `string` | Not in backend penalty schema | Add to backend or remove from FE |

**Recommended Action**: These appear to be frontend convenience fields. Document as frontend-only and ensure they're not sent to backend.

## Behavioral Mismatches 🧪

These work but have different types, formats, or naming that could cause confusion:

### 2. Time Format Inconsistencies
**File References**: `apiDataContract.ts:528-552`, `php-02-Endpoints-and-Contracts.md:151`

| Field | FE Format | BE Format | Current Handling | Risk Level |
|-------|-----------|-----------|------------------|------------|
| `clock` | `"MM:SS"` string | `number` seconds OR `"MM:SS"` | Transformer converts | 🧪 Medium |
| `timeRemaining` | `"MM:SS"` string | `number` seconds | Transformer converts | 🧪 Medium |

**Issue**: Backend accepts both formats but documentation is unclear about which is preferred.  
**Fix**: Standardize on one format or clearly document both are acceptable.

### 3. Result vs ResultCode Confusion
**File References**: `apiDataContract.ts:395-396`, `php-02-Endpoints-and-Contracts.md:236`

| FE Field | BE Field | Mapping Direction | Issue |
|----------|----------|------------------|--------|
| `resultCode` | `result` | FE → BE | FE sends `resultCode`, BE expects `result` |
| `result` | `resultCode` | BE → FE | BE may send `resultCode`, FE expects `result` |

**Current Fix**: Bidirectional mapping in transformer  
**Risk**: Confusion in debugging and API docs

### 4. Possession Format Variations
**File References**: `apiDataContract.ts:557-597`

| Frontend | Backend | Status |
|----------|---------|---------|
| `'H'\|'V'` | `'H'\|'V'\|'home'\|'visitor'` | BE supports both |

**Issue**: Backend is more flexible than frontend  
**Risk**: Low - transformer handles conversion

### 5. Player/Team Reference Case Inconsistency
**File References**: Multiple locations

| Field Type | FE Format | BE Format | Example |
|------------|-----------|-----------|---------|
| Player fields | `camelCase` | `PascalCase` | `firstName` vs `FirstName` |
| IDs | `snake_case` | `PascalCase` | `player_id` vs `PlayerID` |

**Impact**: Potential data mapping errors in roster/player operations

### 6. Penalty Field Name Mismatches
**File References**: `apiDataContract.ts:280-294`

| FE Field | BE Field | Type Match | Handled by Transformer |
|----------|----------|------------|----------------------|
| `team` | `penalized_team` | ✅ | ✅ |
| `code` | `penalty_type` | ✅ | ✅ |
| `yards` | `yards_enforced` | ✅ | ✅ |

**Status**: Well handled by transformer, but creates API documentation confusion

### 7. Statistics Field Abbreviations
**File References**: `apiDataContract.ts:62-69`

| FE Field (Abbreviated) | BE Field (Full) | Clarity Issue |
|----------------------|-----------------|---------------|
| `passComp` | `pass_completions` | Abbreviation not obvious |
| `passAtt` | `pass_attempts` | Abbreviation not obvious |
| `passYds` | `passing_yards` | Abbreviation not obvious |
| `rushAtt` | `rushing_attempts` | Abbreviation not obvious |
| `rushYds` | `rushing_yards` | Abbreviation not obvious |

**Impact**: Developer confusion, harder to maintain

## Detailed Analysis by Category

### Game State Fields
- **Status**: 🟢 Well aligned
- **Issues**: Minor time format variations
- **Transformer Coverage**: Excellent

### Play Data Fields  
- **Status**: 🟡 Mostly aligned with some confusion
- **Key Issues**: `result`/`resultCode` bidirectional mapping
- **Transformer Coverage**: Good

### Penalty Fields
- **Status**: 🟡 Good but confusing field names
- **Key Issues**: Different field names for same concepts
- **Transformer Coverage**: Excellent

### Player/Team References
- **Status**: 🔴 Inconsistent casing patterns
- **Key Issues**: `camelCase` vs `PascalCase` inconsistency
- **Transformer Coverage**: Partial

### Statistics Fields
- **Status**: 🟡 Functional but unclear abbreviations
- **Key Issues**: Abbreviated vs full field names
- **Transformer Coverage**: Good

## Transformer Analysis

### Well-Handled Transformations
```typescript
// These work correctly
period: frontendData.period || frontendData.quarter
time_remaining: frontendData.time_remaining || clockToSeconds(frontendData.clock)
possession: possessionToBackend(frontendData.possession)
```

### Missing/Incomplete Transformations
```typescript
// These need attention
tertiaryPlayerID: // No backend mapping
playContext: // Frontend-only field  
PlayerID: // Inconsistent casing not handled
```

### Recommended Transformer Improvements
1. **Add validation** for frontend-only fields
2. **Standardize case conversion** for player/team references
3. **Document bidirectional mappings** clearly
4. **Add type checking** for time format conversions

## Recommended Fixes

### Priority 1: Fix Blocking Issues
```typescript
// Remove or document frontend-only fields
const cleanedPlayData = {
  ...playData,
  // Remove FE-only fields before sending to BE
  tertiaryPlayerID: undefined,
  playContext: undefined,
  newContext: undefined
};
```

### Priority 2: Standardize Field Names
```typescript
// Choose one naming convention
const PENALTY_FIELD_MAP = {
  team: 'penalized_team',        // BE name
  code: 'penalty_type',          // BE name  
  yards: 'yards_enforced'        // BE name
};
```

### Priority 3: Improve Documentation
- Document **both** time formats as acceptable
- Clarify **result vs resultCode** usage patterns
- Standardize **case conventions** across all docs

### Priority 4: Add Validation
```typescript
// Validate time formats
static validateTimeFormat(time: string | number): boolean {
  if (typeof time === 'number') return time >= 0 && time <= 3600;
  if (typeof time === 'string') return /^\d{1,2}:\d{2}$/.test(time);
  return false;
}
```

## Testing Recommendations

### Unit Tests Needed
1. **Time format conversions** (string ↔ number)
2. **Possession format conversions** ('H'/'V' ↔ 'home'/'visitor')  
3. **Field name transformations** (all camelCase ↔ snake_case)
4. **Penalty array transformations** (field mapping)

### Integration Tests Needed
1. **Full play submission** with all field types
2. **Game state round-trip** (FE → BE → FE)
3. **Error handling** for invalid field formats
4. **Backward compatibility** with both result/resultCode

## Impact Assessment

### Low Risk (Continue Current Approach)
- Standard camelCase ↔ snake_case conversions
- Time format flexibility (backend accepts both)
- Possession format flexibility

### Medium Risk (Monitor Closely)
- Result/ResultCode bidirectional mapping
- Statistics field abbreviations
- Player field case inconsistencies

### High Risk (Fix Required)
- Frontend-only fields being sent to backend
- Undocumented field mappings in penalty arrays

## Action Items

### Immediate (This Sprint)
- [ ] Document frontend-only fields clearly
- [ ] Add validation to prevent sending FE-only fields to backend
- [ ] Update API documentation for time format flexibility

### Short Term (Next Sprint)
- [ ] Standardize player/team field casing
- [ ] Add comprehensive transformer unit tests
- [ ] Document all field mapping decisions

### Long Term (Future Sprint)  
- [ ] Consider eliminating abbreviations in statistics
- [ ] Standardize on single naming convention where possible
- [ ] Add TypeScript strict mode for better type checking

---

**Next Review**: After implementing immediate fixes  
**Owner**: Frontend/Backend API Team  
**Risk Level**: Medium - System works but has potential confusion points